package com.example.salespost.Model;

public class CordinatesModel {
    private double mLatitude;
    private double mLongitude;
    private String mName;



    public CordinatesModel(double mLatitude, double mLongitude, String mName) {
        this.mLatitude = mLatitude;
        this.mLongitude = mLongitude;
        this.mName = mName;
    }


    public CordinatesModel() {

    }

    public double getmLatitude() {
        return mLatitude;
    }

    public void setmLatitude(double mLatitude) {
        this.mLatitude = mLatitude;
    }

    public double getmLongitude() {
        return mLongitude;
    }

    public void setmLongitude(double mLongitude) {
        this.mLongitude = mLongitude;
    }

    public String getmName() {
        return mName;
    }

    public void setmName(String mName) {
        this.mName = mName;
    }
}