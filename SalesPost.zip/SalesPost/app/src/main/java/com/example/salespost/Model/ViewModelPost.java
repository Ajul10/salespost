package com.example.salespost.Model;

public class ViewModelPost {



}
